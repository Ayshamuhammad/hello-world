<?php
require "header.php";
?>

    
    <!-- end of nav bar -->

<br><br>
<div class="container">
    <h3 class="text-center"><br>Order Food<br></h3>   
    <div class="row">
        <div class="col-md-6 offset-md-3">   
 
        
        
        
    
<?php
if(isset($_SESSION['user_id'])){
    echo '<p class="text-white bg-dark text-center">Welcome '. $_SESSION['username'] .', Order your food here!</p>';
      
	$falooda = $_REQUEST['falooda'];
	$rfalooda = $_REQUEST['rfalooda'];
	$icream = $_REQUEST['icream'];
	$falooda_price = $falooda*5;
	$rfalooda_price = $rfalooda*7;
	$icream_price = $icream*4;
	$total = $falooda_price+$rfalooda_price+$icream_price;
	
  //error handling:
    
    if(isset($_GET['error3'])){
        if($_GET['error3'] == "emptyfields") {   //douleuei bazw ta errors apo ta headers.. prp na bgalw to requiered
            echo '<h5 class="bg-danger text-center">Fill all fields, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidfname") {   
            echo '<h5 class="bg-danger text-center">Invalid First Name, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidlname") {   
            echo '<h5 class="bg-danger text-center">Invalid Last Name, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidtele") {   
            echo '<h5 class="bg-danger text-center">Invalid Telephone, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "invalidcomment") {   
            echo '<h5 class="bg-danger text-center">Invalid Comment, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "invalidguests") {   
            echo '<h5 class="bg-danger text-center">Invalid Guests, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "full") {   
            echo '<h5 class="bg-danger text-center">Reservations are full this date and timezone, Please try again!</h5>';
        }
    }
        if(isset($_GET['reservation'])) {   
           if($_GET['reservation'] == "success"){ 
            echo '<h5 class="bg-success text-center">Your reservation was successfull!</h5>';
        }
        }
        echo'<br>';



    

    
    
     //payment page
    echo '  
        
    <div class="signup-form">
        <form action="order_confirm.php" method="post">
            <div class="form-group">
            <label>Falooda    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  '.$falooda .' x £5 &nbsp;=&nbsp;&nbsp; £'.$falooda_price.'</label><br>
			<label>Royal Falooda&nbsp;&nbsp; '.$rfalooda .' x £7 &nbsp;=&nbsp;&nbsp; £'.$rfalooda_price.'</label><br>
			<label>Ice Cream &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   '.$icream .' x £4 &nbsp;=&nbsp;&nbsp; £'.$icream_price.'</label><br>
			<label>Total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   £'.$total.' (Incl. of all taxes.)</label><br>

            </div>
			
			<div class="form-group">
            <label>Name on Card</label>
                <input type="text" class="form-control" name="card_name" placeholder="Enter your name on card" required="required">
                
            </div>
            <div class="form-group">
            <label>Card Number</label>
                <input type="text" class="form-control" name="card_no" placeholder="Enter the card number" required="required">
                
            </div>   
			<div class="form-group">
            <label>Expiry Date</label>
                <input type="text" class="form-control" name="exp_date" placeholder="MM/YY" required="required">
                
            </div>
			<label>CVV</label>
                <input type="text" class="form-control" name="cvv" placeholder="CVV" required="required">
                
            </div>
			<br>
            <div class="form-group">
            <button type="submit" name="reserv-submit" class="btn btn-dark btn-lg btn-block">Confirm Order</button>
            </div>
        </form>
        <br><br>
    </div>
    ';  
    }

    else {
        echo '	<p class="text-center text-danger"><br>You are currently not logged in!<br></p>
       <p class="text-center">In order to make a order food you have to create an account!<br><br><p>';  
        
    }
    ?>

             
        </div>
    </div>
</div>
<br><br>


<?php
require "footer.php";
?>