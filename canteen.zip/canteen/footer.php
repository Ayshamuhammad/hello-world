<!--footer-->
<footer>
	<div class="container">
		<div class="footer-box">
			<?php 
				date_default_timezone_set('Asia/Kolkata');
				$date = date("Y-m-d");
				$newDate = date("d-m-Y", strtotime($date));
			?>
			 <div class="container">
			   
			<p>Contact Us:Falooda Groups,East Street, London</p>
			<p>Email:falooda1234@gmail.com</p>
			<p>Contact No:239874980</p>
			<p>Rate Us</p>
				</div>
				 </div>
				
			<p align="right">Copyright &copy; <?php echo date("Y"); ?> Deepak Yadav</p>
		</div>
	</div>
</footer>
